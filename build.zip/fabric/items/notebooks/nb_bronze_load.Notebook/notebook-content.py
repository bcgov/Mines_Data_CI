# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "896cd6b0-6cd0-47e5-8438-f50dde9564b8",
# META       "default_lakehouse_name": "mcm_mdp_lh1_dev",
# META       "default_lakehouse_workspace_id": "475a3e70-610e-49ae-be54-dd2c31167535",
# META       "known_lakehouses": [
# META         {
# META           "id": "896cd6b0-6cd0-47e5-8438-f50dde9564b8"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run nb_config

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# nb_bronze_load — append-only Bronze loader, OPTIMIZED.
# Per entity: read ALL new raw parquet files in ONE spark.read (Spark parallelizes internally),
# stamp per-file lineage from input_file_name(), write ONCE. Idempotency via a manifest
# (bronze.load_manifest) — no per-file COUNT scans. Entities processed in PARALLEL (thread pool).
# REBUILD=True drops every bronze table + the manifest and reloads from raw (our audit columns
# become the single source of truth); set False after the one-time rebuild.
from pyspark.sql.functions import (lit, current_timestamp, sha2, concat_ws, col, coalesce,
                                   input_file_name, element_at, split, regexp_extract,
                                   to_timestamp, to_date)
from notebookutils import mssparkutils
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
import re
import uuid
import traceback

# RAW_ROOT_PATH (Files/raw/parquet) and BRONZE_SCHEMA come from nb_config / vl_mdp.
TARGET_SCHEMA = BRONZE_SCHEMA
MANIFEST_TABLE = "bronze.load_manifest"
# read the manifest by absolute path (spark.catalog can lag across sessions)
MANIFEST_PATH = f"Tables/{TARGET_SCHEMA}/load_manifest"   # relative to the default lakehouse
SUMMARY_TABLE = "bronze.load_summary"
REBUILD = False         # clean rebuild done; routine runs are incremental (by-path file skip)
MAX_WORKERS = 8

spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "LEGACY")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "LEGACY")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "LEGACY")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "LEGACY")
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
try:
    spark.conf.set("spark.scheduler.mode", "FAIR")
except Exception as e:
    print(f"scheduler.mode set skipped: {e}")


def get_table_name(entity):
    e = entity.strip()
    if e.lower().startswith("public."):
        e = e[7:]
    return e.replace(".", "_").replace("-", "_").replace(" ", "_").lower()


def get_entities():
    return sorted([i.name.strip("/") for i in mssparkutils.fs.ls(RAW_ROOT_PATH) if i.isDir])


def get_all_parquet_files(entity):
    """Walk <RAW_ROOT_PATH>/<entity>/<yyyy>/<mm>/<dd>/*.parquet (numeric folders only)."""
    found, base = [], f"{RAW_ROOT_PATH}/{entity}"
    try:
        for y in mssparkutils.fs.ls(base):
            if not y.name.strip("/").isdigit():
                continue
            for m in mssparkutils.fs.ls(y.path):
                if not m.name.strip("/").isdigit():
                    continue
                for d in mssparkutils.fs.ls(m.path):
                    if not d.name.strip("/").isdigit():
                        continue
                    for f in mssparkutils.fs.ls(d.path):
                        if f.name.lower().endswith(".parquet"):
                            found.append((f.name, f.path))
    except Exception as e:
        print(f"list {entity}: {e}")
    return found


def file_ts(name):
    m = re.search(r"(\d{8}_\d{6})", name)
    return datetime.strptime(m.group(1), "%Y%m%d_%H%M%S") if m else None


def bronze_tbl_path(table):
    return f"Tables/{TARGET_SCHEMA}/{table}"   # relative to the default lakehouse


def loaded_files_for(table):
    """Files already present in the bronze table itself (by path — robust to catalog/metastore
    lag, and the data is its own source of truth). Empty set if the table doesn't exist yet."""
    try:
        return {r["bronze_file_name"] for r in
                spark.read.format("delta").load(bronze_tbl_path(table))
                .select("bronze_file_name").distinct().collect()}
    except Exception:
        return set()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print("=" * 80)
print(f"BRONZE LOAD START (optimized){' [REBUILD]' if REBUILD else ''}")
print("=" * 80)

RUN_ID = str(uuid.uuid4())
START = datetime.now()
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {TARGET_SCHEMA}")

if REBUILD:
    spark.sql(f"DROP TABLE IF EXISTS {MANIFEST_TABLE}")

results, manifest_rows = [], []
_lock = threading.Lock()


def process_entity(entity):
    table = get_table_name(entity)
    target = f"{TARGET_SCHEMA}.{table}"
    if REBUILD:
        spark.sql(f"DROP TABLE IF EXISTS {target}")

    existing = set() if REBUILD else loaded_files_for(table)   # already-loaded files (by path)
    files = get_all_parquet_files(entity)
    todo = [(n, p) for (n, p) in files if file_ts(n) is not None and n not in existing]
    if not todo:
        return (entity, "SKIPPED", 0, [])

    paths = [p for (_, p) in todo]
    df = spark.read.option("int96RebaseMode", "LEGACY").option("datetimeRebaseMode", "LEGACY").parquet(*paths)
    data_cols = df.columns  # original source columns (before control columns)
    df = (df
          .withColumn("bronze_file_name", element_at(split(input_file_name(), "/"), -1))
          .withColumn("bronze_file_timestamp",
                      to_timestamp(regexp_extract(col("bronze_file_name"), r"(\d{8}_\d{6})", 1), "yyyyMMdd_HHmmss"))
          .withColumn("bronze_load_date", to_date(col("bronze_file_timestamp")))
          .withColumn("dl_load_id", lit(RUN_ID))
          .withColumn("dl_load_ts", current_timestamp())
          .withColumn("dl_rowhash",
                      sha2(concat_ws("||", *[coalesce(col(c).cast("string"), lit("")) for c in data_cols]), 256)))

    mode = "overwrite" if REBUILD else "append"   # append creates the table if absent
    opt = "overwriteSchema" if mode == "overwrite" else "mergeSchema"
    (df.write.format("delta").partitionBy("bronze_load_date").mode(mode)
        .option(opt, "true").saveAsTable(target))

    rows = [(entity, n, file_ts(n)) for (n, _) in todo]
    return (entity, "LOADED", len(todo), rows)


with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
    futs = {ex.submit(process_entity, e): e for e in get_entities()}
    for fut in as_completed(futs):
        e = futs[fut]
        try:
            entity, status, nfiles, mrows = fut.result()
            with _lock:
                results.append((entity, status, nfiles, None))
                manifest_rows.extend(mrows)
            print(f"{status:8} {entity}: {nfiles} files")
        except Exception as ex2:
            with _lock:
                results.append((e, "FAILED", 0, str(ex2)[:1000]))
            print(f"FAILED {e}: {ex2}")
            traceback.print_exc()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.types import StructType, StructField, StringType, LongType, TimestampType

# Manifest (append loaded files; REBUILD already dropped it so this is a fresh write).
if manifest_rows:
    msch = StructType([StructField("entity", StringType()), StructField("bronze_file_name", StringType()),
                       StructField("bronze_file_timestamp", TimestampType())])
    mdf = (spark.createDataFrame(manifest_rows, msch)
           .withColumn("run_id", lit(RUN_ID)).withColumn("loaded_at", current_timestamp()))
    mode = "overwrite" if REBUILD else "append"
    mdf.write.format("delta").mode(mode).option("mergeSchema", "true").saveAsTable(MANIFEST_TABLE)

# Run summary.
ssch = StructType([StructField("entity", StringType()), StructField("status", StringType()),
                   StructField("files_loaded", LongType()), StructField("error", StringType())])
srows = [(r[0], r[1], int(r[2]), r[3]) for r in results]
(spark.createDataFrame(srows, ssch)
    .withColumn("run_id", lit(RUN_ID)).withColumn("run_ts", current_timestamp())
    .write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(SUMMARY_TABLE))

loaded_n = sum(1 for r in results if r[1] == "LOADED")
skipped_n = sum(1 for r in results if r[1] == "SKIPPED")
failed_n = sum(1 for r in results if r[1] == "FAILED")
files_n = sum(r[2] for r in results)
print("=" * 80)
print(f"BRONZE LOAD DONE | entities loaded={loaded_n} skipped={skipped_n} failed={failed_n} | "
      f"files={files_n} | RUN_ID={RUN_ID} duration={(datetime.now()-START).total_seconds():.1f}s")
print("=" * 80)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
